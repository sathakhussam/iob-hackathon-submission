
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../components/dashboard/AppHeader';
import Sidebar from '../components/dashboard/Sidebar';
import { ChevronRight, ChevronDown, Phone, Mail, MessageSquare } from 'lucide-react';

const HelpPage: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const navigate = useNavigate();
  
  const faqs = [
    {
      question: "How do I change my password?",
      answer: "Go to Settings > Security > Change Password. Follow the instructions to set a new password. Make sure to use a strong password that includes uppercase letters, lowercase letters, numbers, and special characters."
    },
    {
      question: "How do I report a lost or stolen card?",
      answer: "Immediately call our 24/7 customer service at 1800-XXX-XXXX to report a lost or stolen card. You can also temporarily freeze your card through the app by going to Cards > Select Card > Freeze Card."
    },
    {
      question: "What are the transaction limits for fund transfers?",
      answer: "NEFT transfers have a daily limit of ₹10,00,000. IMPS transfers have a daily limit of ₹5,00,000. UPI transfers have a daily limit of ₹1,00,000. These limits may vary based on your account type and banking relationship."
    },
    {
      question: "How can I update my contact information?",
      answer: "You can update your contact information by visiting the Profile section. Click on the edit icon next to your phone number or email address, enter the new information, and verify it through OTP."
    },
    {
      question: "What should I do if I see an unauthorized transaction?",
      answer: "If you notice an unauthorized transaction, immediately report it by calling our customer service at 1800-XXX-XXXX. You should also consider changing your password and PIN as a precautionary measure."
    }
  ];
  
  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <AppHeader 
        onMenuToggle={() => setSidebarOpen(!sidebarOpen)}
        userName="Rajesh Kumar"
      />
      
      <Sidebar 
        isOpen={sidebarOpen} 
        onClose={() => setSidebarOpen(false)} 
      />
      
      <main className="md:ml-64 p-4">
        <div className="container mx-auto max-w-3xl">
          <div className="flex items-center mb-6">
            <button 
              onClick={() => navigate('/dashboard')}
              className="text-bank-primary mr-2"
            >
              Dashboard
            </button>
            <ChevronRight className="w-4 h-4 text-gray-500 mr-2" />
            <h1 className="text-xl font-bold">Help & Support</h1>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="banking-card flex flex-col items-center justify-center text-center p-6">
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <Phone className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-medium mb-2">Call Us</h3>
              <p className="text-sm text-gray-500 mb-4">24/7 Customer Support</p>
              <a href="tel:18001234567" className="btn-bank-primary text-sm">
                1800-123-4567
              </a>
            </div>
            
            <div className="banking-card flex flex-col items-center justify-center text-center p-6">
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                <Mail className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="font-medium mb-2">Email Us</h3>
              <p className="text-sm text-gray-500 mb-4">Get assistance via email</p>
              <a href="mailto:support@iob.com" className="btn-bank-primary text-sm">
                support@iob.com
              </a>
            </div>
            
            <div className="banking-card flex flex-col items-center justify-center text-center p-6">
              <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mb-4">
                <MessageSquare className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="font-medium mb-2">Live Chat</h3>
              <p className="text-sm text-gray-500 mb-4">Chat with our support team</p>
              <button className="btn-bank-primary text-sm">
                Start Chat
              </button>
            </div>
          </div>
          
          <div className="banking-card mb-6">
            <h2 className="text-lg font-semibold mb-4">Frequently Asked Questions</h2>
            
            <div className="space-y-3">
              {faqs.map((faq, index) => (
                <div key={index} className="border rounded-lg overflow-hidden">
                  <button
                    className="w-full px-4 py-3 flex justify-between items-center bg-gray-50 hover:bg-gray-100"
                    onClick={() => toggleFaq(index)}
                  >
                    <span className="font-medium">{faq.question}</span>
                    <ChevronDown className={`w-5 h-5 transition-transform ${openFaq === index ? 'transform rotate-180' : ''}`} />
                  </button>
                  
                  {openFaq === index && (
                    <div className="p-4 bg-white">
                      <p className="text-gray-600">{faq.answer}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          <div className="banking-card">
            <h2 className="text-lg font-semibold mb-4">Contact Form</h2>
            
            <form>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Your Name
                  </label>
                  <input
                    type="text"
                    className="auth-input"
                    placeholder="Enter your name"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    className="auth-input"
                    placeholder="Enter your email"
                  />
                </div>
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Subject
                </label>
                <input
                  type="text"
                  className="auth-input"
                  placeholder="What is your query about?"
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Message
                </label>
                <textarea
                  className="auth-input min-h-[120px]"
                  placeholder="Describe your issue in detail"
                ></textarea>
              </div>
              
              <button type="submit" className="btn-bank-primary">
                Submit Query
              </button>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
};

export default HelpPage;
