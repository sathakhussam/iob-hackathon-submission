
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useState, useEffect } from "react";

import SplashScreen from "./pages/SplashScreen";
import HomePage from "./pages/HomePage";
import SignUpPage from "./pages/SignUpPage";
import SignUpOtpVerificationPage from "./pages/SignUpOtpVerificationPage";
import FaceBiometricPage from "./pages/FaceBiometricPage";
import VoiceBiometricPage from "./pages/VoiceBiometricPage";
import SignUpCompletePage from "./pages/SignUpCompletePage";
import LoginPage from "./pages/LoginPage";
import PasswordPage from "./pages/PasswordPage";
import OtpVerificationPage from "./pages/OtpVerificationPage";
import BiometricVerificationPage from "./pages/BiometricVerificationPage";
import Dashboard from "./pages/Dashboard";
import FundTransfer from "./pages/FundTransfer";
import AccountEnquiry from "./pages/AccountEnquiry";
import PinChange from "./pages/PinChange";
import ProfilePage from "./pages/ProfilePage";
import SettingsPage from "./pages/SettingsPage";
import HelpPage from "./pages/HelpPage";
import NotFound from "./pages/NotFound";
import Index from "./pages/Index";

const queryClient = new QueryClient();

const App = () => {
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  if (showSplash) {
    return <SplashScreen />;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/home" element={<HomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<SignUpPage />} />
            <Route path="/signup/verify-otp" element={<SignUpOtpVerificationPage />} />
            <Route path="/signup/biometric-face" element={<FaceBiometricPage />} />
            <Route path="/signup/voice-capture" element={<VoiceBiometricPage />} />
            <Route path="/signup/complete" element={<SignUpCompletePage />} />
            <Route path="/password" element={<PasswordPage />} />
            <Route path="/otp-verification" element={<OtpVerificationPage />} />
            <Route path="/biometric-verification" element={<BiometricVerificationPage />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/fund-transfer" element={<FundTransfer />} />
            <Route path="/account-enquiry" element={<AccountEnquiry />} />
            <Route path="/pin-change" element={<PinChange />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="/help" element={<HelpPage />} />
            <Route path="/index" element={<Navigate to="/home" replace />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
