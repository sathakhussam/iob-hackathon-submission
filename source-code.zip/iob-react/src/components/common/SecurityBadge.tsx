
import React from 'react';
import { Shield, Lock } from 'lucide-react';

interface SecurityBadgeProps {
  type?: 'shield' | 'lock';
  className?: string;
}

const SecurityBadge: React.FC<SecurityBadgeProps> = ({ 
  type = 'shield', 
  className = "" 
}) => {
  return (
    <div className={`flex items-center text-sm text-bank-primary ${className}`}>
      {type === 'shield' ? (
        <Shield className="w-4 h-4 mr-1" />
      ) : (
        <Lock className="w-4 h-4 mr-1" />
      )}
      <span>Secure Banking</span>
    </div>
  );
};

export default SecurityBadge;
