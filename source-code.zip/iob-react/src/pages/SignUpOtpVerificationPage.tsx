
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import AuthLayout from '../components/auth/AuthLayout';
import OtpInput from '../components/auth/OtpInput';
import { useToast } from "@/hooks/use-toast";

interface LocationState {
  phone?: string;
}

const SignUpOtpVerificationPage: React.FC = () => {
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [timeLeft, setTimeLeft] = useState(60);
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  
  const { phone } = (location.state as LocationState) || {};
  
  // Redirect if phone is not available
  useEffect(() => {
    if (!phone) {
      navigate('/signup', { replace: true });
    }
  }, [phone, navigate]);

  // Countdown timer for OTP
  useEffect(() => {
    if (timeLeft <= 0) return;
    
    const intervalId = setInterval(() => {
      setTimeLeft(timeLeft - 1);
    }, 1000);
    
    return () => clearInterval(intervalId);
  }, [timeLeft]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (otp.length !== 6) {
      toast({
        title: "Invalid OTP",
        description: "Please enter a valid 6-digit OTP",
        variant: "destructive",
      });
      return;
    }
    
    setLoading(true);
    
    // Simulate OTP verification
    setTimeout(() => {
      setLoading(false);
      navigate('/signup/biometric-face', { state: { phone } });
    }, 1000);
  };

  const handleResendOtp = () => {
    toast({
      title: "OTP Sent",
      description: "A new OTP has been sent to your registered mobile number",
    });
    setTimeLeft(60);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const maskedPhone = phone ? `${phone.substring(0, 2)}******${phone.substring(phone.length - 2)}` : '';

  return (
    <AuthLayout 
      title="OTP Verification"
      subtitle={`Please enter the 6-digit OTP sent to ${maskedPhone}`}
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        <OtpInput length={6} onChange={setOtp} />
        
        <div className="text-center text-sm">
          {timeLeft > 0 ? (
            <p className="text-gray-500">
              Resend OTP in <span className="font-medium">{formatTime(timeLeft)}</span>
            </p>
          ) : (
            <button 
              type="button" 
              onClick={handleResendOtp}
              className="text-bank-accent font-medium hover:underline"
            >
              Resend OTP
            </button>
          )}
        </div>
        
        <button
          type="submit"
          disabled={loading || otp.length !== 6}
          className="btn-bank-primary w-full flex justify-center"
        >
          {loading ? (
            <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          ) : (
            'Verify & Continue'
          )}
        </button>
        
        <div className="text-center">
          <button
            type="button"
            onClick={() => navigate('/signup')}
            className="text-bank-accent text-sm font-medium hover:underline"
          >
            ← Back to Registration
          </button>
        </div>
      </form>
    </AuthLayout>
  );
};

export default SignUpOtpVerificationPage;
