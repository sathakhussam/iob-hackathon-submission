const moment = require('moment');

exports.roundToNearest5 = (time) => {
  const minutes = time.minutes();
  const rounded = Math.round(minutes / 5) * 5;
  return time.minutes(rounded).seconds(0);
}

exports.getNCenterTimes = (times, n) => {
  const moments = times.map(t => moment(t, "HH:mm"));
  const min = moment.min(moments);
  const max = moment.max(moments);
  const duration = moment.duration(max.diff(min));
  const intervalMinutes = duration.asMinutes() / (n + 1);

  const result = [];
  for (let i = 1; i <= n; i++) {
    const rawTime = moment(min).add(intervalMinutes * i, 'minutes');
    const roundedTime = roundToNearest5(rawTime);
    result.push(roundedTime.format("HH:mm"));
  }

  return result;
}
