
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../components/dashboard/AppHeader';
import Sidebar from '../components/dashboard/Sidebar';
import { ChevronRight, Download, Filter, Search } from 'lucide-react';

interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
  balance: number;
}

const AccountEnquiry: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  
  // Mock data
  const transactions: Transaction[] = [
    {
      id: '1001',
      date: '2025-04-09',
      description: 'Salary Credit',
      amount: 45000,
      type: 'credit',
      balance: 156750.42
    },
    {
      id: '1002',
      date: '2025-04-08',
      description: 'Amazon Payment',
      amount: 2500,
      type: 'debit',
      balance: 111750.42
    },
    {
      id: '1003',
      date: '2025-04-05',
      description: 'Electric Bill',
      amount: 1200,
      type: 'debit',
      balance: 114250.42
    },
    {
      id: '1004',
      date: '2025-04-03',
      description: 'Grocery Store',
      amount: 850,
      type: 'debit',
      balance: 115450.42
    },
    {
      id: '1005',
      date: '2025-04-01',
      description: 'Refund Processed',
      amount: 10000,
      type: 'credit',
      balance: 116300.42
    },
    {
      id: '1006',
      date: '2025-03-29',
      description: 'Mobile Recharge',
      amount: 499,
      type: 'debit',
      balance: 106300.42
    },
    {
      id: '1007',
      date: '2025-03-25',
      description: 'Restaurant Payment',
      amount: 1850,
      type: 'debit',
      balance: 106799.42
    },
    {
      id: '1008',
      date: '2025-03-20',
      description: 'Interest Credit',
      amount: 750,
      type: 'credit',
      balance: 108649.42
    },
  ];
  
  const filteredTransactions = transactions.filter(
    (transaction) => 
      transaction.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.amount.toString().includes(searchQuery)
  );
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <AppHeader 
        onMenuToggle={() => setSidebarOpen(!sidebarOpen)}
        userName="Rajesh Kumar"
      />
      
      <Sidebar 
        isOpen={sidebarOpen} 
        onClose={() => setSidebarOpen(false)} 
      />
      
      <main className="md:ml-64 p-4">
        <div className="container mx-auto max-w-4xl">
          <div className="flex items-center mb-6">
            <button 
              onClick={() => navigate('/dashboard')}
              className="text-bank-primary mr-2"
            >
              Dashboard
            </button>
            <ChevronRight className="w-4 h-4 text-gray-500 mr-2" />
            <h1 className="text-xl font-bold">Account Enquiry</h1>
          </div>
          
          <div className="banking-card mb-6">
            <div className="flex justify-between mb-4">
              <h2 className="text-lg font-semibold">Account Summary</h2>
              <span className="text-sm text-gray-500">A/C: XXXX7890</span>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-500 mb-1">Available Balance</p>
                <p className="text-xl font-bold text-bank-primary">{formatCurrency(156750.42)}</p>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-500 mb-1">Total Credits (30 days)</p>
                <p className="text-xl font-bold text-green-600">{formatCurrency(55750)}</p>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-500 mb-1">Total Debits (30 days)</p>
                <p className="text-xl font-bold text-red-600">{formatCurrency(6899)}</p>
              </div>
            </div>
          </div>
          
          <div className="banking-card">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-semibold">Transaction History</h2>
              
              <div className="flex space-x-2">
                <button className="p-2 border rounded-lg hover:bg-gray-50">
                  <Filter className="w-5 h-5 text-gray-600" />
                </button>
                <button className="p-2 border rounded-lg hover:bg-gray-50">
                  <Download className="w-5 h-5 text-gray-600" />
                </button>
              </div>
            </div>
            
            <div className="mb-4">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search transactions..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="auth-input pl-10"
                />
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Description
                    </th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Amount
                    </th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Balance
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredTransactions.map((transaction) => (
                    <tr key={transaction.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm text-gray-600">
                        {formatDate(transaction.date)}
                      </td>
                      <td className="px-4 py-3 text-sm font-medium">
                        {transaction.description}
                      </td>
                      <td className={`px-4 py-3 text-sm font-medium text-right ${
                        transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {transaction.type === 'credit' ? '+' : '-'}
                        {formatCurrency(transaction.amount)}
                      </td>
                      <td className="px-4 py-3 text-sm font-medium text-right">
                        {formatCurrency(transaction.balance)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              
              {filteredTransactions.length === 0 && (
                <div className="py-8 text-center text-gray-500">
                  No transactions found matching your search.
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AccountEnquiry;
