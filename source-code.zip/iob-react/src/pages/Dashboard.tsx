
import React, { useState } from 'react';
import AppHeader from '../components/dashboard/AppHeader';
import Sidebar from '../components/dashboard/Sidebar';
import AccountCard from '../components/dashboard/AccountCard';
import QuickActions from '../components/dashboard/QuickActions';
import TransactionList, { Transaction } from '../components/dashboard/TransactionList';
import FinanceSummary from '../components/dashboard/FinanceSummary';

const Dashboard: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  // Mock data
  const transactions: Transaction[] = [
    { 
      id: '1', 
      type: 'debit', 
      amount: 2500, 
      description: 'Amazon Payment', 
      date: 'Today, 10:30 AM',
      category: 'Shopping'
    },
    { 
      id: '2', 
      type: 'credit', 
      amount: 45000, 
      description: 'Salary Credit', 
      date: 'Apr 05, 2025',
      category: 'Income'
    },
    { 
      id: '3', 
      type: 'debit', 
      amount: 1200, 
      description: 'Electric Bill', 
      date: 'Apr 03, 2025',
      category: 'Utilities'
    },
    { 
      id: '4', 
      type: 'debit', 
      amount: 850, 
      description: 'Grocery Store', 
      date: 'Apr 02, 2025',
      category: 'Food'
    },
    { 
      id: '5', 
      type: 'credit', 
      amount: 10000, 
      description: 'Refund Processed', 
      date: 'Apr 01, 2025',
      category: 'Refund'
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <AppHeader 
        onMenuToggle={() => setSidebarOpen(!sidebarOpen)}
        userName="Rajesh Kumar"
      />
      
      <Sidebar 
        isOpen={sidebarOpen} 
        onClose={() => setSidebarOpen(false)} 
      />
      
      <main className="md:ml-64 p-4">
        <div className="container mx-auto max-w-5xl">
          <h1 className="text-2xl font-bold mb-6">Welcome to Indian Overseas Bank, Rajesh</h1>
          
          <div className="grid grid-cols-1 gap-6">
            <AccountCard 
              accountType="Savings Account"
              accountNumber="12345678901234"
              balance={156750.42}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-6">
                <QuickActions />
                <TransactionList transactions={transactions} />
              </div>
              
              <FinanceSummary />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
