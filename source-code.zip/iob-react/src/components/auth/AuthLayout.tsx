
import React from 'react';
import Logo from '../common/Logo';
import SecurityBadge from '../common/SecurityBadge';

interface AuthLayoutProps {
  children: React.ReactNode;
  title: string;
  subtitle?: string;
}

const AuthLayout: React.FC<AuthLayoutProps> = ({ children, title, subtitle }) => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <div className="flex justify-between items-center p-4 border-b">
        <Logo />
        <SecurityBadge />
      </div>
      
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-8">
        <div className="w-full max-w-md animate-fade-in">
          <h1 className="text-2xl font-bold text-bank-dark mb-2">{title}</h1>
          {subtitle && <p className="text-gray-600 mb-6">{subtitle}</p>}
          {children}
        </div>
      </div>
      
      <div className="p-4 text-center text-xs text-gray-500">
        <p>© {new Date().getFullYear()} Solution Seekers. All rights reserved.</p>
        <p className="mt-1">Version 1.0.0</p>
      </div>
    </div>
  );
};

export default AuthLayout;
