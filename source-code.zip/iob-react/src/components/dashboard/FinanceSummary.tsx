
import React from 'react';
import { 
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';

const FinanceSummary: React.FC = () => {
  const data = [
    { name: 'Jan', income: 45000, expense: 32000 },
    { name: 'Feb', income: 52000, expense: 38000 },
    { name: 'Mar', income: 49000, expense: 36000 },
    { name: 'Apr', income: 63000, expense: 40000 },
    { name: 'May', income: 58000, expense: 45000 },
    { name: 'Jun', income: 61000, expense: 39000 },
  ];
  
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(value);
  };
  
  return (
    <div className="banking-card">
      <h2 className="text-lg font-semibold mb-4">Income & Expenses</h2>
      
      <div className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data}
            margin={{ top: 10, right: 10, left: 10, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="name" tick={{ fontSize: 12 }} />
            <YAxis 
              tickFormatter={(value) => `₹${value/1000}k`} 
              tick={{ fontSize: 12 }}
            />
            <Tooltip 
              formatter={(value: number) => [formatCurrency(value), '']}
              labelStyle={{ fontWeight: 'bold' }}
            />
            <Legend />
            <Bar 
              dataKey="income" 
              name="Income" 
              fill="#4CAF50" 
              radius={[4, 4, 0, 0]} 
            />
            <Bar 
              dataKey="expense" 
              name="Expense" 
              fill="#F44336" 
              radius={[4, 4, 0, 0]} 
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default FinanceSummary;
