const mongoose = require("mongoose")

// Country, balance, risk_score,
const transactionSchema = new mongoose.Schema({
}, {
    versionKey: false
})

const Transaction = mongoose.model("Transaction", transactionSchema)

module.exports = Transaction