
import React from 'react';
import { Link } from 'react-router-dom';
import Logo from '../components/common/Logo';
import { Button } from "@/components/ui/button";
import { Bell, MapPin, Phone, Info } from 'lucide-react';

const HomePage: React.FC = () => {
  // Mock announcements
  const announcements = [
    {
      id: 1,
      title: "New Mobile Banking Features",
      description: "We've added new security features to our mobile banking app.",
      date: "April 15, 2025"
    },
    {
      id: 2,
      title: "Revised Interest Rates",
      description: "Savings account interest rates have been revised to 4.5% p.a.",
      date: "April 10, 2025"
    },
    {
      id: 3,
      title: "Holiday Notice",
      description: "All branches will be closed on April 25, 2025 for a national holiday.",
      date: "April 5, 2025"
    }
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto p-4 flex justify-between items-center">
          <Logo className="h-12" withText={true} />
          <div className="hidden md:flex space-x-6">
            <Link to="/about" className="text-gray-600 hover:text-bank-primary">About Us</Link>
            <Link to="/services" className="text-gray-600 hover:text-bank-primary">Services</Link>
            <Link to="/branches" className="text-gray-600 hover:text-bank-primary">Branch Locator</Link>
            <Link to="/contact" className="text-gray-600 hover:text-bank-primary">Contact Us</Link>
          </div>
          <div className="flex space-x-3">
            <Link to="/signup">
              <Button variant="outline" className="border-bank-primary text-bank-primary hover:bg-bank-primary hover:text-white">
                Sign Up
              </Button>
            </Link>
            <Link to="/login">
              <Button className="bg-bank-primary hover:bg-bank-secondary text-white">
                Login
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-bank-primary to-bank-secondary text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl">
            <h1 className="text-4xl font-bold mb-4">Welcome to Indian Overseas Bank</h1>
            <p className="text-xl mb-8">Experience secure banking with advanced AI-powered biometric authentication.</p>
            <div className="flex flex-wrap gap-4">
              <Link to="/signup">
                <Button size="lg" variant="secondary" className="bg-white text-bank-primary hover:bg-gray-100">
                  Open an Account
                </Button>
              </Link>
              <Link to="/login">
                <Button size="lg" className="bg-transparent border-2 border-white hover:bg-white hover:text-bank-primary">
                  Login to Banking
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Announcements Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex items-center mb-8">
            <Bell className="w-6 h-6 mr-3 text-bank-primary" />
            <h2 className="text-2xl font-bold">Latest Updates & Announcements</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {announcements.map((announcement) => (
              <div key={announcement.id} className="border rounded-lg p-6 hover:shadow-md transition-shadow">
                <h3 className="font-bold text-lg mb-2">{announcement.title}</h3>
                <p className="text-gray-600 mb-3">{announcement.description}</p>
                <p className="text-sm text-gray-500">{announcement.date}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Links */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold mb-8 text-center">Essential Banking Services</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div className="p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <Info className="w-10 h-10 mb-4 mx-auto text-bank-primary" />
              <h3 className="font-semibold mb-2">About IOB</h3>
              <p className="text-sm text-gray-600">Learn about our history and mission</p>
            </div>
            <div className="p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <MapPin className="w-10 h-10 mb-4 mx-auto text-bank-primary" />
              <h3 className="font-semibold mb-2">Find Branches</h3>
              <p className="text-sm text-gray-600">Locate our ATMs and branches near you</p>
            </div>
            <div className="p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <Phone className="w-10 h-10 mb-4 mx-auto text-bank-primary" />
              <h3 className="font-semibold mb-2">Contact Us</h3>
              <p className="text-sm text-gray-600">24/7 customer support</p>
            </div>
            <div className="p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <Bell className="w-10 h-10 mb-4 mx-auto text-bank-primary" />
              <h3 className="font-semibold mb-2">Notifications</h3>
              <p className="text-sm text-gray-600">Stay updated with bank news</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-auto">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <Logo className="mb-4" withText={false} />
              <p className="text-gray-300">Indian Overseas Bank - Secure Banking</p>
            </div>
            <div>
              <h3 className="font-semibold mb-3">Quick Links</h3>
              <ul className="space-y-2 text-gray-300">
                <li><Link to="/about" className="hover:text-white">About Us</Link></li>
                <li><Link to="/services" className="hover:text-white">Services</Link></li>
                <li><Link to="/branches" className="hover:text-white">Branch Locator</Link></li>
                <li><Link to="/contact" className="hover:text-white">Contact Us</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-3">Contact Information</h3>
              <address className="text-gray-300 not-italic">
                Central Office<br />
                763, Anna Salai<br />
                Chennai - 600 002<br />
                Phone: 1800-425-4445
              </address>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-6 text-center text-gray-400 text-sm">
            <p>© {new Date().getFullYear()} Solution Seekers. All rights reserved.</p>
            <p className="mt-1">Version 1.0.0</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
