
import React from 'react';
import { ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

export interface Transaction {
  id: string;
  type: 'credit' | 'debit';
  amount: number;
  description: string;
  date: string;
  category?: string;
}

interface TransactionListProps {
  transactions: Transaction[];
}

const TransactionList: React.FC<TransactionListProps> = ({ transactions }) => {
  return (
    <div className="banking-card">
      <h2 className="text-lg font-semibold mb-4">Recent Transactions</h2>
      
      {transactions.length === 0 ? (
        <p className="text-gray-500 text-center py-4">No recent transactions</p>
      ) : (
        <div className="space-y-3">
          {transactions.map((transaction) => (
            <div 
              key={transaction.id}
              className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0"
            >
              <div className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 ${
                  transaction.type === 'credit' 
                    ? 'bg-green-100 text-green-600' 
                    : 'bg-red-100 text-red-600'
                }`}>
                  {transaction.type === 'credit' 
                    ? <ArrowDownLeft className="w-4 h-4" /> 
                    : <ArrowUpRight className="w-4 h-4" />
                  }
                </div>
                
                <div>
                  <p className="font-medium">{transaction.description}</p>
                  <p className="text-xs text-gray-500">{transaction.date}</p>
                </div>
              </div>
              
              <div className={`font-semibold ${
                transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'
              }`}>
                {transaction.type === 'credit' ? '+' : '-'}
                {new Intl.NumberFormat('en-IN', {
                  style: 'currency',
                  currency: 'INR'
                }).format(transaction.amount)}
              </div>
            </div>
          ))}
        </div>
      )}
      
      {transactions.length > 0 && (
        <div className="mt-4 text-center">
          <Link to="/account-enquiry" className="text-bank-accent font-medium hover:underline">
            View All Transactions
          </Link>
        </div>
      )}
    </div>
  );
};

export default TransactionList;
