
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../components/dashboard/AppHeader';
import Sidebar from '../components/dashboard/Sidebar';
import { useToast } from "@/hooks/use-toast";
import { ChevronRight, Users, Building, Globe } from 'lucide-react';

const FundTransfer: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('within');
  const [amount, setAmount] = useState<string>('');
  const [accountNumber, setAccountNumber] = useState<string>('');
  const [ifscCode, setIfscCode] = useState<string>('');
  const [purpose, setPurpose] = useState<string>('');
  const [loading, setLoading] = useState(false);
  
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const tabs = [
    { id: 'within', label: 'Within IOB', icon: Users },
    { id: 'other', label: 'Other Bank', icon: Building },
    { id: 'international', label: 'International', icon: Globe },
  ];
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!amount || !accountNumber || (activeTab === 'other' && !ifscCode)) {
      toast({
        title: "Missing Information",
        description: "Please fill all the required fields",
        variant: "destructive",
      });
      return;
    }
    
    // Simulate processing
    setLoading(true);
    
    setTimeout(() => {
      setLoading(false);
      
      toast({
        title: "Transfer Successful",
        description: `₹${amount} has been transferred successfully`,
        variant: "default",
      });
      
      // Reset form and redirect to dashboard
      setAmount('');
      setAccountNumber('');
      setIfscCode('');
      setPurpose('');
      
      navigate('/dashboard');
    }, 2000);
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <AppHeader 
        onMenuToggle={() => setSidebarOpen(!sidebarOpen)}
        userName="Rajesh Kumar"
      />
      
      <Sidebar 
        isOpen={sidebarOpen} 
        onClose={() => setSidebarOpen(false)} 
      />
      
      <main className="md:ml-64 p-4">
        <div className="container mx-auto max-w-2xl">
          <div className="flex items-center mb-6">
            <button 
              onClick={() => navigate('/dashboard')}
              className="text-bank-primary mr-2"
            >
              Dashboard
            </button>
            <ChevronRight className="w-4 h-4 text-gray-500 mr-2" />
            <h1 className="text-xl font-bold">Fund Transfer</h1>
          </div>
          
          <div className="banking-card">
            <div className="mb-6">
              <div className="flex border-b">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    className={`flex items-center py-3 px-4 ${
                      activeTab === tab.id 
                        ? 'border-b-2 border-bank-primary text-bank-primary font-medium' 
                        : 'text-gray-500'
                    }`}
                    onClick={() => setActiveTab(tab.id)}
                  >
                    <tab.icon className="w-4 h-4 mr-2" />
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-1">
                  Amount (₹) <span className="text-red-500">*</span>
                </label>
                <input
                  id="amount"
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Enter amount"
                  className="auth-input"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="accountNumber" className="block text-sm font-medium text-gray-700 mb-1">
                  Recipient Account Number <span className="text-red-500">*</span>
                </label>
                <input
                  id="accountNumber"
                  type="text"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  placeholder="Enter account number"
                  className="auth-input"
                  required
                />
              </div>
              
              {activeTab !== 'within' && (
                <div>
                  <label htmlFor="ifscCode" className="block text-sm font-medium text-gray-700 mb-1">
                    IFSC Code <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="ifscCode"
                    type="text"
                    value={ifscCode}
                    onChange={(e) => setIfscCode(e.target.value)}
                    placeholder="Enter IFSC code"
                    className="auth-input"
                    required={activeTab !== 'within'}
                  />
                </div>
              )}
              
              <div>
                <label htmlFor="purpose" className="block text-sm font-medium text-gray-700 mb-1">
                  Purpose
                </label>
                <input
                  id="purpose"
                  type="text"
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  placeholder="Enter purpose (optional)"
                  className="auth-input"
                />
              </div>
              
              <div className="pt-4">
                <button
                  type="submit"
                  disabled={loading}
                  className="btn-bank-primary w-full flex justify-center"
                >
                  {loading ? (
                    <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  ) : (
                    'Transfer Funds'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
};

export default FundTransfer;
