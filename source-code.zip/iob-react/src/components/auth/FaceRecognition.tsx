
import React, { useState, useEffect, useRef } from 'react';
import { User, Camera, CheckCircle } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface FaceRecognitionProps {
  onCapture: () => void;
}

type FaceDirection = 'center' | 'left' | 'right' | 'up' | 'down';

const FaceRecognition: React.FC<FaceRecognitionProps> = ({ onCapture }) => {
  const [recording, setRecording] = useState(false);
  const [captureComplete, setCaptureComplete] = useState(false);
  const [currentDirection, setCurrentDirection] = useState<FaceDirection>('center');
  const [capturedImages, setCapturedImages] = useState<string[]>([]);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const { toast } = useToast();

  const directions: FaceDirection[] = ['center', 'left', 'right', 'up', 'down'];
  const capturesPerDirection = 4; // Will result in 20 total images (4 per direction)
  
  useEffect(() => {
    startVideoStream();
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
        streamRef.current = null;
      }
    };
  }, []);

  const startVideoStream = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: true,
        audio: false
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      streamRef.current = stream;
    } catch (err) {
      console.error("Error accessing camera:", err);
      toast({
        title: "Camera Access Required",
        description: "Please allow camera access to complete facial registration",
        variant: "destructive",
      });
    }
  };

  const captureImage = () => {
    if (!videoRef.current) return;
    
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.drawImage(videoRef.current, 0, 0);
    return canvas.toDataURL('image/jpeg');
  };

  const startRecording = async () => {
    setRecording(true);
    let currentImages: string[] = [];
    
    for (const direction of directions) {
      setCurrentDirection(direction);
      
      // Show instruction toast for each direction
      toast({
        title: `Turn your face ${direction}`,
        description: "Hold position while we capture images",
      });
      
      // Wait for user to adjust position
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Capture multiple images for current direction
      for (let i = 0; i < capturesPerDirection; i++) {
        const image = captureImage();
        if (image) {
          currentImages.push(image);
        }
        // Small delay between captures
        await new Promise(resolve => setTimeout(resolve, 200));
      }
    }
    
    setCapturedImages(currentImages);
    completeCapture();
  };

  const completeCapture = () => {
    setRecording(false);
    setCaptureComplete(true);
    toast({
      title: "Face Registration Complete",
      description: "Successfully captured facial biometrics",
    });
    onCapture();
  };

  const getDirectionInstructions = () => {
    switch (currentDirection) {
      case 'center': return 'Look directly at the camera';
      case 'left': return 'Slowly turn your face to the left';
      case 'right': return 'Slowly turn your face to the right';
      case 'up': return 'Slowly tilt your face upward';
      case 'down': return 'Slowly tilt your face downward';
      default: return 'Follow the instructions';
    }
  };

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-64 h-64 bg-gray-100 rounded-full mb-6 flex items-center justify-center overflow-hidden">
        {captureComplete ? (
          <div className="absolute inset-0 flex items-center justify-center bg-green-100">
            <CheckCircle className="w-32 h-32 text-green-600" />
            <div className="absolute bottom-4 text-green-600 font-semibold">Registration Complete</div>
          </div>
        ) : (
          <>
            <video 
              ref={videoRef} 
              autoPlay 
              muted
              playsInline
              className="absolute inset-0 w-full h-full object-cover"
              style={{ display: streamRef.current ? 'block' : 'none' }}
            />
            {!streamRef.current && <User className="w-32 h-32 text-gray-400" />}
            {recording && (
              <div className="absolute inset-0 border-4 border-red-500 animate-pulse rounded-full"></div>
            )}
          </>
        )}
      </div>
      
      {!captureComplete && (
        <>
          <div className="text-center mb-6">
            <h3 className="text-lg font-semibold mb-2">{getDirectionInstructions()}</h3>
            <p className="text-sm text-gray-600">
              {recording 
                ? "Please follow the instructions while we capture your face from different angles" 
                : "We'll capture multiple images of your face from different angles"}
            </p>
          </div>
          
          {!recording && (
            <button
              onClick={startRecording}
              className="flex items-center justify-center gap-2 btn-bank-primary w-full max-w-xs"
            >
              <Camera className="w-5 h-5" />
              Start Face Registration
            </button>
          )}
        </>
      )}
    </div>
  );
};

export default FaceRecognition;
