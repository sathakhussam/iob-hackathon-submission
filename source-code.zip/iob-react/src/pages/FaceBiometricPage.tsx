
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import AuthLayout from '../components/auth/AuthLayout';
import { useToast } from "@/hooks/use-toast";
import { ArrowRight } from 'lucide-react';
import FaceRecognition from '../components/auth/FaceRecognition';
import { Button } from "@/components/ui/button";

interface LocationState {
  phone?: string;
}

const FaceBiometricPage: React.FC = () => {
  const [biometricCaptured, setBiometricCaptured] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  
  const { phone } = (location.state as LocationState) || {};
  
  // Redirect if phone is not available
  useEffect(() => {
    if (!phone) {
      navigate('/signup', { replace: true });
    }
  }, [phone, navigate]);

  const handleCapture = () => {
    setBiometricCaptured(true);
  };

  const handleContinue = () => {
    if (!biometricCaptured) {
      toast({
        title: "Face Registration Required",
        description: "Please complete the facial registration process before continuing",
        variant: "destructive",
      });
      return;
    }
    
    setLoading(true);
    
    // Simulate processing
    setTimeout(() => {
      setLoading(false);
      navigate('/signup/voice-capture', { state: { phone } });
    }, 1500);
  };

  return (
    <AuthLayout 
      title="Facial Biometric Registration"
      subtitle="Please follow the instructions to register your face"
    >
      <div className="space-y-8">
        <FaceRecognition onCapture={handleCapture} />
        
        <div className="text-center">
          <p className="text-sm text-gray-600 mb-6">
            Your facial biometrics will be securely stored and used for identity verification.
          </p>
        </div>
        
        <Button
          className="w-full btn-bank-primary flex justify-center items-center gap-2"
          onClick={handleContinue}
          disabled={loading || !biometricCaptured}
        >
          {loading ? (
            <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
          ) : (
            <>
              Continue to Voice Registration
              <ArrowRight className="w-5 h-5" />
            </>
          )}
        </Button>
        
        <div className="text-center">
          <button
            onClick={() => navigate('/signup/verify-otp')}
            className="text-bank-accent text-sm font-medium hover:underline"
          >
            ← Back to OTP Verification
          </button>
        </div>
      </div>
    </AuthLayout>
  );
};

export default FaceBiometricPage;
