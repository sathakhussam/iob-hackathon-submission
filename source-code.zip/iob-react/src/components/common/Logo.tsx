
import React from 'react';

interface LogoProps {
  className?: string;
  withText?: boolean;
}

const Logo: React.FC<LogoProps> = ({ className = "", withText = true }) => {
  return (
    <div className={`flex items-center ${className}`}>
      <div className="flex items-center justify-center bg-bank-primary rounded-full w-10 h-10 text-white font-bold">
        IOB
      </div>
      {withText && (
        <div className="ml-2 text-bank-primary font-bold text-xl">
          Indian Overseas Bank
        </div>
      )}
    </div>
  );
};

export default Logo;
