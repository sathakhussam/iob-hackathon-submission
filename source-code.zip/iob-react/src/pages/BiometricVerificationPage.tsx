
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import AuthLayout from '../components/auth/AuthLayout';
import FaceRecognition from '../components/auth/FaceRecognition';
import { Shield } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface LocationState {
  customerId?: string;
}

const BiometricVerificationPage: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [verificationComplete, setVerificationComplete] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  
  const { customerId } = (location.state as LocationState) || {};
  
  // Redirect to login if customerId is not available
  useEffect(() => {
    if (!customerId) {
      navigate('/', { replace: true });
    }
  }, [customerId, navigate]);

  const handleCapture = () => {
    setVerificationComplete(true);
    
    // Show risk assessment notification
    toast({
      title: "Risk Assessment Complete",
      description: "Your identity has been verified with low risk score",
    });
    
    // Proceed to dashboard after short delay
    setTimeout(() => {
      setLoading(true);
      
      setTimeout(() => {
        navigate('/dashboard');
      }, 1000);
    }, 1500);
  };

  return (
    <AuthLayout 
      title="Facial Recognition Verification"
      subtitle="Complete the facial and voice recognition challenge for secure access"
    >
      <div className="space-y-6">
        <div className="banking-card border border-gray-200">
          <FaceRecognition onCapture={handleCapture} />
        </div>
        
        {verificationComplete && (
          <div className="flex items-center justify-center p-3 bg-green-50 text-green-700 rounded-lg animate-fade-in">
            <Shield className="w-5 h-5 mr-2" />
            <span className="font-medium">Verification successful</span>
          </div>
        )}
        
        {verificationComplete && (
          <button
            disabled={loading}
            className="btn-bank-primary w-full flex justify-center mt-4"
            onClick={() => navigate('/dashboard')}
          >
            {loading ? (
              <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : (
              'Continue to Dashboard'
            )}
          </button>
        )}
      </div>
    </AuthLayout>
  );
};

export default BiometricVerificationPage;
