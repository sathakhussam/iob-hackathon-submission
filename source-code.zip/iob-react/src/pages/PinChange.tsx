
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../components/dashboard/AppHeader';
import Sidebar from '../components/dashboard/Sidebar';
import { ChevronRight, Eye, EyeOff, AlertCircle, CheckCircle } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

const PinChange: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentPin, setCurrentPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [showCurrentPin, setShowCurrentPin] = useState(false);
  const [showNewPin, setShowNewPin] = useState(false);
  const [showConfirmPin, setShowConfirmPin] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const validatePin = (pin: string): boolean => {
    // PIN must be 4 digits
    return /^\d{4}$/.test(pin);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validatePin(currentPin)) {
      toast({
        title: "Invalid Current PIN",
        description: "PIN must be 4 digits",
        variant: "destructive",
      });
      return;
    }
    
    if (!validatePin(newPin)) {
      toast({
        title: "Invalid New PIN",
        description: "PIN must be 4 digits",
        variant: "destructive",
      });
      return;
    }
    
    if (newPin !== confirmPin) {
      toast({
        title: "PIN Mismatch",
        description: "New PIN and Confirm PIN do not match",
        variant: "destructive",
      });
      return;
    }
    
    if (currentPin === newPin) {
      toast({
        title: "Same PIN",
        description: "New PIN cannot be the same as current PIN",
        variant: "destructive",
      });
      return;
    }
    
    // Simulate processing
    setLoading(true);
    
    setTimeout(() => {
      setLoading(false);
      
      toast({
        title: "PIN Changed Successfully",
        description: "Your PIN has been updated",
        variant: "default",
      });
      
      // Reset form and redirect to dashboard
      setCurrentPin('');
      setNewPin('');
      setConfirmPin('');
      
      navigate('/dashboard');
    }, 2000);
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <AppHeader 
        onMenuToggle={() => setSidebarOpen(!sidebarOpen)}
        userName="Rajesh Kumar"
      />
      
      <Sidebar 
        isOpen={sidebarOpen} 
        onClose={() => setSidebarOpen(false)} 
      />
      
      <main className="md:ml-64 p-4">
        <div className="container mx-auto max-w-2xl">
          <div className="flex items-center mb-6">
            <button 
              onClick={() => navigate('/dashboard')}
              className="text-bank-primary mr-2"
            >
              Dashboard
            </button>
            <ChevronRight className="w-4 h-4 text-gray-500 mr-2" />
            <h1 className="text-xl font-bold">PIN Change</h1>
          </div>
          
          <div className="banking-card">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                <div className="flex">
                  <AlertCircle className="w-5 h-5 text-yellow-600 mr-2 flex-shrink-0" />
                  <div className="text-sm text-yellow-700">
                    <p className="font-medium">Important</p>
                    <ul className="list-disc list-inside mt-1">
                      <li>PIN must be 4 digits</li>
                      <li>Do not share your PIN with anyone</li>
                      <li>Avoid using sequential or repeated numbers</li>
                    </ul>
                  </div>
                </div>
              </div>
              
              <div>
                <label htmlFor="currentPin" className="block text-sm font-medium text-gray-700 mb-1">
                  Current PIN <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    id="currentPin"
                    type={showCurrentPin ? "text" : "password"}
                    value={currentPin}
                    onChange={(e) => setCurrentPin(e.target.value)}
                    maxLength={4}
                    placeholder="Enter current PIN"
                    className="auth-input pr-10"
                    required
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                    onClick={() => setShowCurrentPin(!showCurrentPin)}
                  >
                    {showCurrentPin ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>
              
              <div>
                <label htmlFor="newPin" className="block text-sm font-medium text-gray-700 mb-1">
                  New PIN <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    id="newPin"
                    type={showNewPin ? "text" : "password"}
                    value={newPin}
                    onChange={(e) => setNewPin(e.target.value)}
                    maxLength={4}
                    placeholder="Enter new PIN"
                    className="auth-input pr-10"
                    required
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                    onClick={() => setShowNewPin(!showNewPin)}
                  >
                    {showNewPin ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
                {newPin && !validatePin(newPin) && (
                  <p className="mt-1 text-sm text-red-600 flex items-center">
                    <AlertCircle className="w-4 h-4 mr-1" />
                    PIN must be 4 digits
                  </p>
                )}
                {newPin && validatePin(newPin) && (
                  <p className="mt-1 text-sm text-green-600 flex items-center">
                    <CheckCircle className="w-4 h-4 mr-1" />
                    Valid PIN format
                  </p>
                )}
              </div>
              
              <div>
                <label htmlFor="confirmPin" className="block text-sm font-medium text-gray-700 mb-1">
                  Confirm PIN <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <input
                    id="confirmPin"
                    type={showConfirmPin ? "text" : "password"}
                    value={confirmPin}
                    onChange={(e) => setConfirmPin(e.target.value)}
                    maxLength={4}
                    placeholder="Confirm new PIN"
                    className="auth-input pr-10"
                    required
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                    onClick={() => setShowConfirmPin(!showConfirmPin)}
                  >
                    {showConfirmPin ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
                {confirmPin && newPin !== confirmPin && (
                  <p className="mt-1 text-sm text-red-600 flex items-center">
                    <AlertCircle className="w-4 h-4 mr-1" />
                    PINs do not match
                  </p>
                )}
                {confirmPin && newPin === confirmPin && validatePin(confirmPin) && (
                  <p className="mt-1 text-sm text-green-600 flex items-center">
                    <CheckCircle className="w-4 h-4 mr-1" />
                    PINs match
                  </p>
                )}
              </div>
              
              <div className="pt-4">
                <button
                  type="submit"
                  disabled={loading || !validatePin(currentPin) || !validatePin(newPin) || newPin !== confirmPin}
                  className="btn-bank-primary w-full flex justify-center"
                >
                  {loading ? (
                    <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                  ) : (
                    'Change PIN'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
};

export default PinChange;
