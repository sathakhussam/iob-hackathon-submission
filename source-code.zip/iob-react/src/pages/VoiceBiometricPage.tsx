
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import AuthLayout from '../components/auth/AuthLayout';
import { useToast } from "@/hooks/use-toast";
import { Mic, MicOff, ArrowRight, CheckCircle } from 'lucide-react';
import { Button } from "@/components/ui/button";

interface LocationState {
  phone?: string;
}

const VoiceBiometricPage: React.FC = () => {
  const [hasMicrophone, setHasMicrophone] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recordingComplete, setRecordingComplete] = useState(false);
  const [currentDigit, setCurrentDigit] = useState<number | null>(null);
  const [completedDigits, setCompletedDigits] = useState<number[]>([]);
  const [loading, setLoading] = useState(false);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  
  const { phone } = (location.state as LocationState) || {};
  
  // Redirect if phone is not available
  useEffect(() => {
    if (!phone) {
      navigate('/signup', { replace: true });
    }
  }, [phone, navigate]);

  // Check microphone availability on component mount
  useEffect(() => {
    const checkMicrophone = async () => {
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const audioDevices = devices.filter(device => device.kind === 'audioinput');
        setHasMicrophone(audioDevices.length > 0);
      } catch (err) {
        console.error("Error checking microphone:", err);
        setHasMicrophone(false);
      }
    };
    
    checkMicrophone();
    
    // Cleanup on unmount
    return () => {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
        mediaRecorderRef.current.stop();
      }
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      audioContextRef.current = new AudioContext();
      
      mediaRecorderRef.current = new MediaRecorder(stream);
      audioChunksRef.current = [];
      
      mediaRecorderRef.current.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };
      
      mediaRecorderRef.current.onstop = () => {
        // Here we would process the recorded audio
        // For now, we'll just mark the current digit as completed
        if (currentDigit !== null) {
          setCompletedDigits(prev => [...prev, currentDigit]);
          
          // If we've recorded all digits, mark as complete
          if (completedDigits.length + 1 >= 10) {
            setRecordingComplete(true);
            setCurrentDigit(null);
          } else {
            // Move to next digit
            setCurrentDigit(completedDigits.length + 1);
          }
        }
      };
      
      mediaRecorderRef.current.start();
      setRecording(true);
      
      // Start with the first digit (0)
      setCurrentDigit(0);
      
      // For demo purposes, we'll automatically "record" each digit
      startDigitRecordingSequence();
      
    } catch (err) {
      console.error("Error accessing microphone:", err);
      toast({
        title: "Microphone Error",
        description: "Unable to access your microphone. Please check permissions.",
        variant: "destructive",
      });
    }
  };

  const startDigitRecordingSequence = () => {
    let currentIndex = 0;
    const recordTime = 2000; // 2 seconds per digit
    
    const recordNextDigit = () => {
      if (currentIndex >= 10) {
        setRecordingComplete(true);
        setCurrentDigit(null);
        stopRecording();
        return;
      }
      
      setCurrentDigit(currentIndex);
      
      // Simulate recording for recordTime
      setTimeout(() => {
        setCompletedDigits(prev => [...prev, currentIndex]);
        currentIndex++;
        recordNextDigit();
      }, recordTime);
    };
    
    recordNextDigit();
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
      
      // Stop all audio tracks
      if (mediaRecorderRef.current.stream) {
        mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      }
    }
    
    setRecording(false);
  };

  const handleContinue = () => {
    setLoading(true);
    
    // Simulate processing
    setTimeout(() => {
      setLoading(false);
      navigate('/signup/complete', { state: { phone } });
    }, 1500);
  };

  const renderDigitStatus = () => {
    return (
      <div className="flex justify-center space-x-2 mt-4">
        {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
          <div 
            key={digit} 
            className={`w-8 h-8 rounded-full flex items-center justify-center ${
              currentDigit === digit 
                ? 'bg-yellow-100 border-2 border-yellow-400 animate-pulse' 
                : completedDigits.includes(digit)
                ? 'bg-green-100 border-2 border-green-500' 
                : 'bg-gray-100 border border-gray-300'
            }`}
          >
            {digit}
          </div>
        ))}
      </div>
    );
  };

  return (
    <AuthLayout 
      title="Voice Biometric Registration"
      subtitle="Please record yourself saying each digit from 0-9 clearly"
    >
      <div className="space-y-6">
        {!hasMicrophone ? (
          <div className="text-center p-6 bg-red-50 rounded-lg">
            <MicOff className="w-12 h-12 mx-auto text-red-500 mb-3" />
            <h3 className="text-lg font-semibold text-red-700">Microphone Not Available</h3>
            <p className="text-red-600 mt-2">
              We couldn't detect a microphone on your device. Please use a device with a microphone to complete the registration.
            </p>
          </div>
        ) : (
          <div className="flex flex-col items-center">
            <div className="relative w-32 h-32 bg-gray-100 rounded-full mb-6 flex items-center justify-center">
              {recording ? (
                <div className="w-full h-full flex items-center justify-center">
                  <Mic className={`w-16 h-16 text-red-500 animate-pulse`} />
                </div>
              ) : recordingComplete ? (
                <CheckCircle className="w-16 h-16 text-green-500" />
              ) : (
                <Mic className="w-16 h-16 text-gray-400" />
              )}
            </div>
            
            {recording && currentDigit !== null && (
              <div className="text-2xl font-bold mb-4">
                Say: "{currentDigit}"
              </div>
            )}
            
            {recordingComplete && (
              <div className="text-center mb-6">
                <h3 className="text-lg font-semibold text-green-700">Voice Registration Complete</h3>
                <p className="text-gray-600">
                  Thank you for registering your voice. This will be used for secure authentication.
                </p>
              </div>
            )}
            
            {renderDigitStatus()}
            
            {!recording && !recordingComplete && (
              <Button
                className="w-full btn-bank-primary flex justify-center items-center gap-2 mt-6"
                onClick={startRecording}
              >
                <Mic className="w-5 h-5" />
                Start Voice Registration
              </Button>
            )}
            
            {recording && (
              <Button
                className="w-full bg-red-500 hover:bg-red-600 text-white flex justify-center items-center gap-2 mt-6"
                onClick={stopRecording}
              >
                <MicOff className="w-5 h-5" />
                Stop Recording
              </Button>
            )}
            
            {recordingComplete && (
              <Button
                className="w-full btn-bank-primary flex justify-center items-center gap-2 mt-6"
                onClick={handleContinue}
                disabled={loading}
              >
                {loading ? (
                  <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                ) : (
                  <>
                    Complete Registration
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </Button>
            )}
          </div>
        )}
      </div>
    </AuthLayout>
  );
};

export default VoiceBiometricPage;
