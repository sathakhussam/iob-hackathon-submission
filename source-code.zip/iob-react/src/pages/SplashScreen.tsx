
import React, { useEffect, useState } from 'react';
import Logo from '../components/common/Logo';

const SplashScreen: React.FC = () => {
  const [progress, setProgress] = useState(0);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 10;
      });
    }, 200);
    
    return () => clearInterval(interval);
  }, []);
  
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-bank-primary to-bank-secondary text-white">
      <div className="animate-fade-in flex flex-col items-center">
        <Logo className="mb-8 scale-150" withText={false} />
        
        <h1 className="text-3xl font-bold mb-2">Indian Overseas Bank</h1>
        <p className="text-white/80 mb-8">Secure AI Banking</p>
        
        <div className="w-64 h-2 bg-white/20 rounded-full overflow-hidden mb-4">
          <div 
            className="h-full bg-white rounded-full transition-all duration-200"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
        
        <p className="text-sm text-white/60">Loading your secure banking experience</p>
      </div>
    </div>
  );
};

export default SplashScreen;
