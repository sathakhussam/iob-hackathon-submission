
import React from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface AccountCardProps {
  accountType: string;
  accountNumber: string;
  balance: number;
}

const AccountCard: React.FC<AccountCardProps> = ({ 
  accountType, 
  accountNumber, 
  balance 
}) => {
  const [showBalance, setShowBalance] = React.useState(false);
  
  const formattedAccountNumber = `XXXX${accountNumber.slice(-4)}`;
  const formattedBalance = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR'
  }).format(balance);
  
  return (
    <div className="banking-card bg-gradient-to-r from-bank-primary to-bank-secondary text-white">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-sm font-medium text-white/80">{accountType}</h3>
          <p className="text-lg font-semibold">{formattedAccountNumber}</p>
        </div>
        <button
          onClick={() => setShowBalance(!showBalance)}
          className="p-1 rounded-full bg-white/20 hover:bg-white/30"
        >
          {showBalance ? (
            <EyeOff className="w-4 h-4" />
          ) : (
            <Eye className="w-4 h-4" />
          )}
        </button>
      </div>
      
      <div>
        <p className="text-sm text-white/80">Available Balance</p>
        <p className="text-2xl font-bold">
          {showBalance ? formattedBalance : '₹ XXXX.XX'}
        </p>
      </div>
    </div>
  );
};

export default AccountCard;
