
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import AuthLayout from '../components/auth/AuthLayout';
import { CheckCircle } from 'lucide-react';
import { Button } from "@/components/ui/button";

interface LocationState {
  phone?: string;
}

const SignUpCompletePage: React.FC = () => {
  const [countdown, setCountdown] = useState(5);
  const navigate = useNavigate();
  const location = useLocation();
  
  const { phone } = (location.state as LocationState) || {};
  
  // Redirect if phone is not available
  useEffect(() => {
    if (!phone) {
      navigate('/signup', { replace: true });
    }
  }, [phone, navigate]);

  // Auto-redirect countdown
  useEffect(() => {
    if (countdown <= 0) {
      navigate('/login');
      return;
    }
    
    const timer = setTimeout(() => {
      setCountdown(countdown - 1);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, [countdown, navigate]);

  return (
    <AuthLayout 
      title="Registration Complete"
      subtitle="Your account has been successfully created"
    >
      <div className="text-center p-8">
        <div className="flex justify-center mb-6">
          <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center">
            <CheckCircle className="w-14 h-14 text-green-600" />
          </div>
        </div>
        
        <h2 className="text-2xl font-bold text-green-700 mb-2">Registration Successful!</h2>
        <p className="text-gray-600 mb-6">
          Thank you for registering with Indian Overseas Bank. Your biometric profile has been created successfully.
        </p>
        
        <div className="mb-8">
          <div className="inline-block px-4 py-2 bg-gray-100 rounded-lg text-gray-700">
            Redirecting to login page in <span className="font-bold">{countdown}</span> seconds
          </div>
        </div>
        
        <Button
          className="w-full btn-bank-primary"
          onClick={() => navigate('/login')}
        >
          Proceed to Login
        </Button>
      </div>
    </AuthLayout>
  );
};

export default SignUpCompletePage;
