
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../components/dashboard/AppHeader';
import Sidebar from '../components/dashboard/Sidebar';
import { ChevronRight, Bell, Lock, Smartphone, Globe, Save } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

const SettingsPage: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [settings, setSettings] = useState({
    notifications: {
      transactionAlerts: true,
      marketingUpdates: false,
      loginAlerts: true,
      newOffers: true
    },
    security: {
      twoFactorAuth: true,
      biometricLogin: true,
      rememberDevice: false,
      sessionTimeout: "15" // minutes
    },
    preferences: {
      defaultAccount: "Savings",
      language: "english",
      theme: "light",
      showBalance: true
    }
  });
  
  const handleCheckboxChange = (category: string, setting: string) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category as keyof typeof prev],
        [setting]: !prev[category as keyof typeof prev][setting as keyof typeof prev[keyof typeof prev]]
      }
    }));
  };
  
  const handleSelectChange = (category: string, setting: string, value: string) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category as keyof typeof prev],
        [setting]: value
      }
    }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Settings Updated",
        description: "Your settings have been updated successfully",
      });
    }, 1000);
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <AppHeader 
        onMenuToggle={() => setSidebarOpen(!sidebarOpen)}
        userName="Rajesh Kumar"
      />
      
      <Sidebar 
        isOpen={sidebarOpen} 
        onClose={() => setSidebarOpen(false)} 
      />
      
      <main className="md:ml-64 p-4">
        <div className="container mx-auto max-w-3xl">
          <div className="flex items-center mb-6">
            <button 
              onClick={() => navigate('/dashboard')}
              className="text-bank-primary mr-2"
            >
              Dashboard
            </button>
            <ChevronRight className="w-4 h-4 text-gray-500 mr-2" />
            <h1 className="text-xl font-bold">Settings</h1>
          </div>
          
          <form onSubmit={handleSubmit}>
            <div className="space-y-6">
              {/* Notifications */}
              <div className="banking-card">
                <div className="flex items-center mb-4">
                  <Bell className="w-5 h-5 text-bank-primary mr-2" />
                  <h2 className="text-lg font-semibold">Notifications</h2>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-sm">Transaction Alerts</label>
                    <input 
                      type="checkbox" 
                      checked={settings.notifications.transactionAlerts}
                      onChange={() => handleCheckboxChange('notifications', 'transactionAlerts')}
                      className="toggle-switch"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <label className="text-sm">Marketing Updates</label>
                    <input 
                      type="checkbox" 
                      checked={settings.notifications.marketingUpdates}
                      onChange={() => handleCheckboxChange('notifications', 'marketingUpdates')}
                      className="toggle-switch"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <label className="text-sm">Login Alerts</label>
                    <input 
                      type="checkbox" 
                      checked={settings.notifications.loginAlerts}
                      onChange={() => handleCheckboxChange('notifications', 'loginAlerts')}
                      className="toggle-switch"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <label className="text-sm">New Offers & Services</label>
                    <input 
                      type="checkbox" 
                      checked={settings.notifications.newOffers}
                      onChange={() => handleCheckboxChange('notifications', 'newOffers')}
                      className="toggle-switch"
                    />
                  </div>
                </div>
              </div>
              
              {/* Security */}
              <div className="banking-card">
                <div className="flex items-center mb-4">
                  <Lock className="w-5 h-5 text-bank-primary mr-2" />
                  <h2 className="text-lg font-semibold">Security</h2>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-sm">Two-Factor Authentication</label>
                    <input 
                      type="checkbox" 
                      checked={settings.security.twoFactorAuth}
                      onChange={() => handleCheckboxChange('security', 'twoFactorAuth')}
                      className="toggle-switch"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <label className="text-sm">Biometric Login</label>
                    <input 
                      type="checkbox" 
                      checked={settings.security.biometricLogin}
                      onChange={() => handleCheckboxChange('security', 'biometricLogin')}
                      className="toggle-switch"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <label className="text-sm">Remember Device</label>
                    <input 
                      type="checkbox" 
                      checked={settings.security.rememberDevice}
                      onChange={() => handleCheckboxChange('security', 'rememberDevice')}
                      className="toggle-switch"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <label className="text-sm">Session Timeout (minutes)</label>
                    <select
                      value={settings.security.sessionTimeout}
                      onChange={(e) => handleSelectChange('security', 'sessionTimeout', e.target.value)}
                      className="auth-input w-24 text-right"
                    >
                      <option value="5">5</option>
                      <option value="10">10</option>
                      <option value="15">15</option>
                      <option value="30">30</option>
                      <option value="60">60</option>
                    </select>
                  </div>
                </div>
              </div>
              
              {/* Preferences */}
              <div className="banking-card">
                <div className="flex items-center mb-4">
                  <Smartphone className="w-5 h-5 text-bank-primary mr-2" />
                  <h2 className="text-lg font-semibold">App Preferences</h2>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-sm">Default Account</label>
                    <select
                      value={settings.preferences.defaultAccount}
                      onChange={(e) => handleSelectChange('preferences', 'defaultAccount', e.target.value)}
                      className="auth-input w-40 text-right"
                    >
                      <option value="Savings">Savings Account</option>
                      <option value="Current">Current Account</option>
                      <option value="Fixed">Fixed Deposit</option>
                    </select>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <label className="text-sm">Language</label>
                    <select
                      value={settings.preferences.language}
                      onChange={(e) => handleSelectChange('preferences', 'language', e.target.value)}
                      className="auth-input w-40 text-right"
                    >
                      <option value="english">English</option>
                      <option value="hindi">Hindi</option>
                      <option value="tamil">Tamil</option>
                      <option value="telugu">Telugu</option>
                    </select>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <label className="text-sm">Theme</label>
                    <select
                      value={settings.preferences.theme}
                      onChange={(e) => handleSelectChange('preferences', 'theme', e.target.value)}
                      className="auth-input w-40 text-right"
                    >
                      <option value="light">Light</option>
                      <option value="dark">Dark</option>
                      <option value="system">System Default</option>
                    </select>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <label className="text-sm">Show Balance</label>
                    <input 
                      type="checkbox" 
                      checked={settings.preferences.showBalance}
                      onChange={() => handleCheckboxChange('preferences', 'showBalance')}
                      className="toggle-switch"
                    />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <button
                type="submit"
                disabled={loading}
                className="btn-bank-primary flex justify-center items-center gap-2"
              >
                {loading ? (
                  <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                ) : (
                  <>
                    <Save className="w-5 h-5" />
                    Save Settings
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
};

export default SettingsPage;
