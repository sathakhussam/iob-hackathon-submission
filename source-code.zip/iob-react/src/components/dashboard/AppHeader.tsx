
import React, { useState } from 'react';
import { Bell, Menu } from 'lucide-react';
import Logo from '../common/Logo';
import { useToast } from "@/hooks/use-toast";

interface AppHeaderProps {
  onMenuToggle: () => void;
  userName: string;
}

const AppHeader: React.FC<AppHeaderProps> = ({ onMenuToggle, userName }) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const { toast } = useToast();
  
  const toggleNotifications = () => {
    setShowNotifications(!showNotifications);
    if (!showNotifications) {
      toast({
        title: "Notifications",
        description: "You have no new notifications",
      });
    }
  };
  
  return (
    <header className="bg-white border-b p-4 sticky top-0 z-10">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={onMenuToggle}
            className="p-1 rounded-full hover:bg-gray-100"
          >
            <Menu className="w-6 h-6 text-bank-dark" />
          </button>
          <Logo />
        </div>
        
        <div className="flex items-center space-x-4">
          <button 
            className="p-1 rounded-full hover:bg-gray-100 relative"
            onClick={toggleNotifications}
          >
            <Bell className="w-6 h-6 text-bank-dark" />
            <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>
          
          <div className="flex items-center">
            <div className="w-8 h-8 bg-bank-primary rounded-full flex items-center justify-center text-white font-semibold">
              {userName.charAt(0)}
            </div>
            <span className="ml-2 text-sm font-medium hidden md:block">{userName}</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default AppHeader;
