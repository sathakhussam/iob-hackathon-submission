const mongoose = require("mongoose")
const Transaction = require("./transaction")
const medianTime = require("../utils/medianTime")

const extendedUserYearlySchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId, // Changed to ObjectId
        ref: "User", // Assuming a Transaction model exists
        required: [true, "ExtendedUserYearly must have user."]
    },
    slotDate: {
        type: Date,
        required: [true, "ExtendedUserYearly must have slotDate."]
    },
    deviceFingerprint: {
        type: String,
        default: ""
    },
    geoLocation: {
        type: {
            latitude: { type: Number, required: true },
            longitude: { type: Number, required: true }
        },
        default: null
    },
    ipAddress: {
        type: String,
        default: ""
    },
    ipAddressRisk: {
        type: Number,
        default: 0
    },
    isIpWithVpn: {
        type: Boolean,
        default: false
    },
    lastTransaction: {
        type: mongoose.Schema.Types.ObjectId, // Changed to ObjectId
        ref: "Transaction", // Assuming a Transaction model exists
        default: null
    },

    averageNoOfTransaction: {
        type: Number,
        default: 0
    }, // This gets updated automatically
    averageAmount: {
        type: Number,
        default: 0
    }, // This gets updated automatically
    averageAmountUpdatedMonth: {
        type: String,
        enum: ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"],
        default: "0"
    },
    noOfTransactions: {
        type: [Number],
        default: [0,0,0,0,0,0,0,0,0,0,0,0]
    }, 
    totalAmountSummation: {
        type: [Number],
        default: [0,0,0,0,0,0,0,0,0,0,0,0]
    },
    mediansOfTimesOfTransactions: {
        type: [Date],
        default: []
    },
    totalOfDeviationTimeFromTransactions: {
        type: [Number],
        default: [0,0,0,0,0,0,0,0,0,0,0,0]
    },
    noOfFailedAttemptsPastHour: {
        type: [Number, Date],
        default: [0, Date.now()]
    },
    previousBeneficiary: {
        type: [mongoose.Schema.Types.ObjectId], // Changed to ObjectId
        ref: "User", // Assuming a Transaction model exists
        default: [],    
    }
}, {
    versionKey: false
})

extendedUserYearlySchema.pre('save', async function(next) {
    if (!this.isModified("totalAmountSummation")) return next()
    let monthLastUpdated;
    for (let i = this.totalAmountSummation.length; i >= 0; i--) {
        if (this.totalAmountSummation[i] > 0) monthLastUpdated = i
    }
    if (monthLastUpdated = 0) monthLastUpdated +=1
    if (parseInt(this.averageAmountUpdatedMonth) - 1 != monthLastUpdated) {
        this.averageAmount = this.totalAmountSummation[monthLastUpdated-1] / this.noOfTransactions[monthLastUpdated-1]
        this.averageNoOfTransaction = this.noOfTransactions[monthLastUpdated-1] / 30
        this.averageAmountUpdatedMonth = `${monthLastUpdated - 1}`

        // Add todo to get the median of time the transactions of every month to be updated with this.
        const currentYear = new Date().getFullYear();
        const startOfYear = new Date(currentYear, 0, 1);
        const endOfYear = new Date(currentYear, 11, 31, 23, 59, 59);

        const transactions = await Transaction.find({
            $or: [
            { fromUser: this.user },
            { toUser: this.user }
            ],
            createdAt: { $gte: startOfYear, $lte: endOfYear }
        });
        const transactionTimestamps = transactions.map(transaction => transaction.createdAt);
        
        // Process the transactions as needed
        this.mediansOfTimesOfTransactions = medianTime.getNCenterTimes(transactionTimestamps, 3)
    }
})


const ExtendedUserYearly = mongoose.model("ExtendedUserYearly", extendedUserYearlySchema)

module.exports = ExtendedUser