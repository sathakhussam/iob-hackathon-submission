
import React from 'react';
import { Send, Search, CreditCard, FileText } from 'lucide-react';
import { Link } from 'react-router-dom';

const QuickActions: React.FC = () => {
  const actions = [
    { icon: Send, label: 'Fund Transfer', path: '/fund-transfer', color: 'bg-blue-100 text-blue-600' },
    { icon: Search, label: 'Account Enquiry', path: '/account-enquiry', color: 'bg-purple-100 text-purple-600' },
    { icon: CreditCard, label: 'PIN Change', path: '/pin-change', color: 'bg-orange-100 text-orange-600' },
    { icon: FileText, label: 'Statement', path: '/account-enquiry?tab=statement', color: 'bg-green-100 text-green-600' },
  ];
  
  return (
    <div className="banking-card">
      <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
      
      <div className="grid grid-cols-4 gap-2">
        {actions.map((action, index) => (
          <Link 
            key={index}
            to={action.path}
            className="flex flex-col items-center p-3 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <div className={`w-10 h-10 rounded-full ${action.color} flex items-center justify-center mb-2`}>
              <action.icon className="w-5 h-5" />
            </div>
            <span className="text-xs text-center font-medium">{action.label}</span>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default QuickActions;
